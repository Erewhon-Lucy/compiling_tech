#include <stdio.h>
#include "ast.h"

#include<stdio.h>

int main(void)
{
    yyparse();
    return 0;
}